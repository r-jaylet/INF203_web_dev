"use strict";

function loadDoc() {
  console.log("loadDoc");
  console.log(this);

  var text_c = new XMLHttpRequest();

  text_c.open("GET", "text.txt");
  text_c.onload = function() {
    var area = document.getElementById("ta");
    area.textContent += this.responseText;
  }
  text_c.send();
}


function loadDoc2() {
  console.log("loadDoc2");
  console.log("loadDoc2\n"+this);

  var text_c = new XMLHttpRequest();

  text_c.open("GET", "text.txt");
  text_c.onload = function() {
    var area = document.getElementById("ta2");
    let p;
    let lines = this.responseText.split("<br/>");
    for (var i in lines) {
      p = document.createElement("p");
      p.textContent = lines[i];
      area.appendChild(p);
    }
  }
  text_c.send();
}
