"use strict";

var s;

function load_slides() {
  console.log('loading slide :');

  var text_c = new XMLHttpRequest();

  text_c.open("GET", "slides.json");
  text_c.onload = function() {
    s = JSON.parse(this.responseText);
    console.log(s);
  }
  text_c.send();
}

load_slides();

function play_slide(url) {
  var area = document.getElementById("SLSH");
  if (area.firstChild) area.removeChild(area.firstChild);
  var frame = document.createElement("iframe");
  frame.src = url;
  area.appendChild(frame);
}

function play() {
  for (var i in s.slides) {
    console.log(s.slides[i]);
    setTimeout(play_slide, 1000 * s.slides[i].time, s.slides[i].url);
  }
}
