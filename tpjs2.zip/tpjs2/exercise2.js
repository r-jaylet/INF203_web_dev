"use strict";

function send() {
  var text_c = new XMLHttpRequest();
  var req = document.getElementById('textedit').value;
  req = "chat.php?phrase=" + req;
  var text_e = document.getElementById("textedit");
  text_c.open("GET", req);
  text_c.onload = function(){
      text_e.value = "";
      console.log(this.responseText);
  }
  text_c.send()
}


function refresh(){
  console.log("refresh");

  var text_c = new XMLHttpRequest();

  text_c.open("GET", "chatlog.txt");
  text_c.onload = function() {
    var area = document.getElementById("ta");
    var lines = this.responseText.split("\n").reverse();
    let n = area.childElementCount;
    var p;
    for (let i=0; i<n; i++)
      div.removeChild(area.firstChild);
    for (let i in lines) {
      if (lines[i] == "") continue;
      p = document.createElement("p");
      p.textContent = lines[i];
      area.appendChild(p);
      if (area.childElementCount == 10) break;
    }
  }
  text_c.send();
}

setInterval(refresh, 1000);
